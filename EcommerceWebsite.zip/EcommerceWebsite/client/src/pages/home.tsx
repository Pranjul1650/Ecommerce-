import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useLocation } from "wouter";
import { Product } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const [_, setLocation] = useLocation();
  const { data: products, isLoading } = useQuery<Product[]>({ 
    queryKey: ["/api/products"]
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Skeleton className="h-64 w-full mb-4" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  const product = products?.[0];

  if (!product) {
    return <div>No products found</div>;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8 items-start">
          <div className="space-y-4">
            <div className="relative aspect-square bg-muted rounded-lg overflow-hidden">
              <img 
                src={product.image} 
                alt={product.name}
                className="w-full h-full object-contain"
                onError={(e) => {
                  const img = e.target as HTMLImageElement;
                  img.src = "/placeholder.png";
                }}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="aspect-square bg-muted rounded-lg" />
              <div className="aspect-square bg-muted rounded-lg" />
              <div className="aspect-square bg-muted rounded-lg" />
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h1 className="text-4xl font-bold tracking-tight">{product.name}</h1>
              <p className="text-2xl font-semibold mt-2">₹{product.price}</p>
              <p className="text-muted-foreground mt-1">{product.size}</p>
            </div>

            <p className="text-lg">{product.description}</p>

            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Key Benefits:</h3>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Natural ayurvedic ingredients</li>
                <li>Rejuvenates skin and body</li>
                <li>Promotes wellness and vitality</li>
                <li>Made with traditional formulation</li>
              </ul>
            </div>

            <Button 
              size="lg" 
              className="w-full md:w-auto"
              onClick={() => setLocation("/checkout")}
            >
              Buy Now
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}