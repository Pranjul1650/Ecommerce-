import { 
  type Product, 
  type InsertProduct,
  type Order,
  type InsertOrder 
} from "@shared/schema";

export interface IStorage {
  getProducts(): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
}

export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private orders: Map<number, Order>;
  private orderId: number;

  constructor() {
    this.products = new Map();
    this.orders = new Map();
    this.orderId = 1;

    // Initialize with Kaya Kalp product
    this.products.set(1, {
      id: 1,
      name: "Kaya Kalp",
      description: "Premium Ayurvedic body care product for natural rejuvenation and wellness",
      price: 450,
      size: "200 Gram",
      image: "/assets/Screenshot 2024-12-18 102225.png"
    });
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createOrder(orderData: InsertOrder): Promise<Order> {
    const order = {
      id: this.orderId++,
      ...orderData
    };
    this.orders.set(order.id, order);
    return order;
  }
}

export const storage = new MemStorage();